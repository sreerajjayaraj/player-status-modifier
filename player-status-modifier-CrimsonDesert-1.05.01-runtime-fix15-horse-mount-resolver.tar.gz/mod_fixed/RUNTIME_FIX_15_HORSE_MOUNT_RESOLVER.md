# Runtime fix 15 - horse mount resolver

Base: fix-14 tracking-hard-guard.

Affinity is intentionally untouched.

Changes:
- Keeps the stable fix-14 player tracking guard.
- Adds a supported mount profile for horse-sized mounts instead of only dragon-sized mounts.
- Broadens context/root-based mount resolution to accept horse health/stamina maxima.
- Does not globally lock every low-health non-player write, to avoid making enemies invulnerable.
- Tightens the health-write player fallback so horse/enemy-sized health entries are not mistaken for player health before the player has been discovered.
- Locks mount health when the entry has been explicitly resolved as `MountHealth`.
- Keeps the old large untracked health fallback for dragon-like mounts only.
- Adds diagnostics for non-player health candidates in the horse range:
  `runtime: observed non-player health candidate ... note=not-locked-without-mount-context`

Expected useful log lines:
- `runtime: tracked mount profile=horse ...`
- `runtime: locked mount health write ... tracked=1`
- `runtime: locked mount-like stamina delta ...`
- `runtime: observed non-player health candidate ... note=not-locked-without-mount-context`

If horse riding still shows no `tracked mount profile=horse`, the horse stamina/health path is not reaching the current stat/context hooks and a new scanner hook will be needed next.
