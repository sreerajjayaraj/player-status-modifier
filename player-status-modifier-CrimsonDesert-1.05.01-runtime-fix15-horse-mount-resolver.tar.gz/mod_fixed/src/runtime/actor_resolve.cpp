#include "runtime/actor_resolve.h"

#include <Windows.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>

namespace {

constexpr int64_t kMountHealthResolveMinMax = 2500000;
constexpr int64_t kMountStaminaResolveMinMax = 300000;
constexpr int64_t kHorseMountHealthResolveMinMax = 40000;
constexpr int64_t kHorseMountStaminaResolveMinMax = 1000;
constexpr int64_t kPlayerHealthWriteFallbackMinMax = 500000;
constexpr uintptr_t kResolveRootEntryScanStart = 0x08;
constexpr uintptr_t kResolveRootEntryScanEnd = 0x200;
constexpr uintptr_t kNearbyStatEntrySearchBack = 0x100;
constexpr uintptr_t kNearbyStatEntrySearchForward = 0x900;

bool IsValidStatEntry(const uintptr_t entry, const int32_t expected_type) {
    if (entry < kMinimumPointerAddress) {
        return false;
    }

    __try {
        if (*reinterpret_cast<const int32_t*>(entry) != expected_type) {
            return false;
        }

        const int64_t current_value = *reinterpret_cast<const int64_t*>(entry + 0x08);
        const int64_t max_value = *reinterpret_cast<const int64_t*>(entry + 0x18);
        return max_value > 0 && current_value >= 0 && current_value <= max_value;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool TryGetStatEntryMaxValue(const uintptr_t entry, const int32_t expected_type, int64_t* const max_value) {
    if (max_value == nullptr) {
        return false;
    }

    __try {
        if (!IsValidStatEntry(entry, expected_type)) {
            return false;
        }

        *max_value = *reinterpret_cast<const int64_t*>(entry + 0x18);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}
bool IsHorseOrDragonHealthMax(const int64_t max_value) {
    return max_value >= kHorseMountHealthResolveMinMax;
}

bool IsHorseOrDragonStaminaMax(const int64_t max_value) {
    return max_value >= kHorseMountStaminaResolveMinMax;
}


uintptr_t TryFindUniqueNearbyStatEntry(const uintptr_t anchor_entry, const int32_t expected_type) {
    if (anchor_entry < kMinimumPointerAddress) {
        return 0;
    }

    const uintptr_t search_start =
        anchor_entry > kNearbyStatEntrySearchBack ? anchor_entry - kNearbyStatEntrySearchBack : anchor_entry;
    const uintptr_t search_end = anchor_entry + kNearbyStatEntrySearchForward;

    uintptr_t found = 0;
    int found_count = 0;

    for (uintptr_t candidate = search_start; candidate <= search_end; candidate += sizeof(uintptr_t)) {
        if (candidate == anchor_entry) {
            continue;
        }

        if (!IsValidStatEntry(candidate, expected_type)) {
            continue;
        }

        found = candidate;
        ++found_count;
        if (found_count > 1) {
            return 0;
        }
    }

    return found_count == 1 ? found : 0;
}

bool IsNearbyTrackedPlayerStatCandidate(const uintptr_t entry, const uintptr_t health_entry) {
    if (entry < kMinimumPointerAddress || health_entry < kMinimumPointerAddress) {
        return false;
    }

    const uintptr_t lower = health_entry > kNearbyStatEntrySearchBack ? health_entry - kNearbyStatEntrySearchBack : health_entry;
    const uintptr_t upper = health_entry + kNearbyStatEntrySearchForward;
    return entry >= lower && entry <= upper;
}

void TryResolveLargeMountStatEntries(const uintptr_t root,
                                     uintptr_t* const health_entry,
                                     uintptr_t* const stamina_entry) {
    if (health_entry == nullptr || stamina_entry == nullptr || root < kMinimumPointerAddress) {
        return;
    }

    uintptr_t best_health_entry = 0;
    int64_t best_health_max = 0;
    uintptr_t best_stamina_entry = 0;
    int64_t best_stamina_max = 0;

    for (uintptr_t offset = kResolveRootEntryScanStart; offset <= kResolveRootEntryScanEnd; offset += sizeof(uintptr_t)) {
        uintptr_t candidate = 0;
        if (!TryReadPointer(root + offset, &candidate) || candidate < kMinimumPointerAddress) {
            continue;
        }

        int64_t candidate_max = 0;
        if (TryGetStatEntryMaxValue(candidate, kHealthId, &candidate_max) &&
            IsHorseOrDragonHealthMax(candidate_max) &&
            candidate_max >= best_health_max) {
            best_health_entry = candidate;
            best_health_max = candidate_max;
        }

        if (TryGetStatEntryMaxValue(candidate, kStaminaId, &candidate_max) &&
            IsHorseOrDragonStaminaMax(candidate_max) &&
            candidate_max >= best_stamina_max) {
            best_stamina_entry = candidate;
            best_stamina_max = candidate_max;
        }
    }

    if (best_health_entry >= kMinimumPointerAddress) {
        *health_entry = best_health_entry;
    }

    if (best_stamina_entry >= kMinimumPointerAddress) {
        *stamina_entry = best_stamina_entry;
    }
}

bool TryResolveActorFromMarker(const uintptr_t marker, uintptr_t* const actor) {
    if (actor == nullptr || marker < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t marker_owner = 0;
    if (!TryReadPointer(marker + 0x8, &marker_owner) || marker_owner < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t resolved_actor = 0;
    if (!TryReadPointer(marker_owner + 0x68, &resolved_actor) || resolved_actor < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t confirmed_marker = 0;
    if (!TryReadPointer(resolved_actor + 0x20, &confirmed_marker) || confirmed_marker != marker) {
        return false;
    }

    *actor = resolved_actor;
    return true;
}

}  // namespace

bool SelectConfig(const ModConfig& config, const int32_t stat_type, StatConfig* const selected) {
    if (selected == nullptr) {
        return false;
    }

    switch (stat_type) {
    case kHealthId:
        *selected = config.health;
        return true;
    case kStaminaId:
        *selected = config.stamina;
        return true;
    case kSpiritId:
        *selected = config.spirit;
        return true;
    default:
        return false;
    }
}

int64_t ClampToRange(const int64_t value, const int64_t minimum, const int64_t maximum) {
    return std::max(minimum, std::min(value, maximum));
}

int64_t ScaleDelta(const int64_t delta, const double multiplier) {
    const double scaled = std::floor(static_cast<double>(delta) * multiplier);
    if (scaled <= 0.0) {
        return 0;
    }

    if (scaled >= static_cast<double>(std::numeric_limits<int64_t>::max())) {
        return std::numeric_limits<int64_t>::max();
    }

    return static_cast<int64_t>(scaled);
}

bool IsTrackedStat(const int32_t stat_type) {
    return stat_type == kHealthId || stat_type == kStaminaId || stat_type == kSpiritId;
}

bool TryAssignPlayerResolvedEntry(const uintptr_t entry, const int32_t stat_type) {
    if (entry < kMinimumPointerAddress || !IsTrackedStat(stat_type)) {
        return false;
    }

    auto resolved = g_player_resolve;
    if (!resolved.valid()) {
        return false;
    }

    bool changed = false;
    switch (stat_type) {
    case kHealthId:
        if (resolved.health_entry >= kMinimumPointerAddress &&
            resolved.health_entry != entry) {
            return false;
        }
        if (resolved.health_entry != entry) {
            resolved.health_entry = entry;
            changed = true;
        }
        break;
    case kStaminaId:
        if (resolved.stamina_entry != entry) {
            resolved.stamina_entry = entry;
            changed = true;
        }
        break;
    case kSpiritId:
        if (resolved.spirit_entry != entry) {
            resolved.spirit_entry = entry;
            changed = true;
        }
        break;
    default:
        break;
    }

    if (!changed) {
        return false;
    }

    g_player_resolve = resolved;
    return true;
}

bool TryBootstrapPlayerResolveFromStatComponent(const uintptr_t entry, const uintptr_t component) {
    if (entry < kMinimumPointerAddress || component < kMinimumPointerAddress) {
        return false;
    }

    const int32_t stat_type = *reinterpret_cast<const int32_t*>(entry);
    if (!IsTrackedStat(stat_type)) {
        return false;
    }

    uintptr_t component_marker = 0;
    if (!TryReadPointer(component, &component_marker) || component_marker < kMinimumPointerAddress) {
        return false;
    }

    ActorResolveSnapshot resolved{};
    if (!TryResolveActorResolveFromMarker(component_marker, &resolved) || !resolved.valid()) {
        return false;
    }

    switch (stat_type) {
    case kHealthId:
        if (resolved.health_entry != entry) {
            return false;
        }
        break;
    case kStaminaId:
        if (resolved.stamina_entry != entry) {
            return false;
        }
        break;
    case kSpiritId:
        if (resolved.spirit_entry != entry) {
            return false;
        }
        break;
    default:
        return false;
    }

    std::lock_guard lock(g_state_mutex);

    const ActorResolveSnapshot existing = g_player_resolve;
    if (existing.health_entry >= kMinimumPointerAddress) {
        // Fix-13: do not let a later stats/component resolver replace the
        // health-write fallback player entry.  In 1.05.01 the stats callback
        // can observe other player-like/companion components long after fall
        // damage has already identified the active player health entry.  The
        // previous fix-12B behavior overwrote g_player_resolve with that later
        // component, causing real player health writes to become "untracked"
        // again.  Only merge the stats resolve when it refers to the same
        // health entry; otherwise keep the working health-write fallback.
        if (resolved.health_entry != existing.health_entry) {
            return false;
        }

        ActorResolveSnapshot merged = existing;
        if (merged.actor < kMinimumPointerAddress) {
            merged.actor = resolved.actor;
        }
        if (merged.marker < kMinimumPointerAddress) {
            merged.marker = resolved.marker;
        }
        if (merged.root < kMinimumPointerAddress) {
            merged.root = resolved.root;
        }
        if (merged.stamina_entry < kMinimumPointerAddress) {
            merged.stamina_entry = resolved.stamina_entry;
        }
        if (merged.spirit_entry < kMinimumPointerAddress) {
            merged.spirit_entry = resolved.spirit_entry;
        }

        g_player_resolve = merged;
        return true;
    }

    if (g_player_resolve.valid()) {
        return false;
    }

    g_player_resolve = resolved;
    ResetTrackedDamageParticipantsLocked();
    return true;
}


bool TryBootstrapPlayerResolveFromHealthWrite(const uintptr_t health_entry) {
    if (health_entry < kMinimumPointerAddress || !IsValidStatEntry(health_entry, kHealthId)) {
        return false;
    }

    int64_t health_max = 0;
    if (!TryGetStatEntryMaxValue(health_entry, kHealthId, &health_max) ||
        health_max < kPlayerHealthWriteFallbackMinMax ||
        health_max >= kMountHealthResolveMinMax) {
        return false;
    }

    // Crimson Desert 1.05.01 can route fall/environment damage through this
    // health writer before the marker/root resolver has observed the player.
    // Fix-3 was stable, but it still required the old fixed stamina offset
    // (health + 0x480), so the valid player health write from 1.05.01 was
    // rejected as "untracked health write skipped".  Keep this fallback narrow:
    // accept the verified health entry only, optionally fill the old stamina /
    // spirit offsets when they happen to match, and avoid any heap/window scan.
    uintptr_t stamina_entry = 0;
    const uintptr_t candidate_stamina_entry = health_entry + kStaminaEntryOffsetFromHealth;
    if (IsValidStatEntry(candidate_stamina_entry, kStaminaId)) {
        stamina_entry = candidate_stamina_entry;
    } else {
        stamina_entry = TryFindUniqueNearbyStatEntry(health_entry, kStaminaId);
    }

    uintptr_t spirit_entry = 0;
    const uintptr_t candidate_spirit_entry = health_entry + kSpiritEntryOffsetFromHealth;
    if (IsValidStatEntry(candidate_spirit_entry, kSpiritId)) {
        spirit_entry = candidate_spirit_entry;
    } else {
        spirit_entry = TryFindUniqueNearbyStatEntry(health_entry, kSpiritId);
    }

    std::lock_guard lock(g_state_mutex);

    if (g_player_resolve.health_entry >= kMinimumPointerAddress) {
        return g_player_resolve.health_entry == health_entry;
    }

    g_player_resolve.health_entry = health_entry;
    g_player_resolve.stamina_entry = stamina_entry;
    g_player_resolve.spirit_entry = spirit_entry;
    return true;
}


bool TryBootstrapPlayerStaminaFromEntry(const uintptr_t stamina_entry) {
    if (stamina_entry < kMinimumPointerAddress || !IsValidStatEntry(stamina_entry, kStaminaId)) {
        return false;
    }

    int64_t stamina_max = 0;
    if (!TryGetStatEntryMaxValue(stamina_entry, kStaminaId, &stamina_max) ||
        stamina_max >= kMountStaminaResolveMinMax) {
        return false;
    }

    std::lock_guard lock(g_state_mutex);

    if (g_player_resolve.stamina_entry == stamina_entry) {
        return true;
    }

    if (g_player_resolve.stamina_entry >= kMinimumPointerAddress ||
        g_player_resolve.health_entry < kMinimumPointerAddress ||
        !IsNearbyTrackedPlayerStatCandidate(stamina_entry, g_player_resolve.health_entry) ||
        stamina_entry == g_player_resolve.health_entry ||
        stamina_entry == g_player_resolve.spirit_entry) {
        return false;
    }

    g_player_resolve.stamina_entry = stamina_entry;
    return true;
}

bool TryBootstrapPlayerSpiritFromEntry(const uintptr_t spirit_entry) {
    if (spirit_entry < kMinimumPointerAddress || !IsValidStatEntry(spirit_entry, kSpiritId)) {
        return false;
    }

    std::lock_guard lock(g_state_mutex);

    if (g_player_resolve.spirit_entry == spirit_entry) {
        return true;
    }

    if (g_player_resolve.spirit_entry >= kMinimumPointerAddress ||
        g_player_resolve.health_entry < kMinimumPointerAddress ||
        !IsNearbyTrackedPlayerStatCandidate(spirit_entry, g_player_resolve.health_entry) ||
        spirit_entry == g_player_resolve.health_entry ||
        spirit_entry == g_player_resolve.stamina_entry) {
        return false;
    }

    g_player_resolve.spirit_entry = spirit_entry;
    return true;
}

bool TryReadPointer(const uintptr_t address, uintptr_t* const value) {
    if (value == nullptr || address < kMinimumPointerAddress) {
        return false;
    }

    __try {
        *value = *reinterpret_cast<const uintptr_t*>(address);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool TryResolveActorResolveFromMarker(const uintptr_t marker,
                                      ActorResolveSnapshot* const resolved,
                                      const uintptr_t actor_hint) {
    if (resolved == nullptr || marker < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t root = 0;
    if (!TryReadPointer(marker + 0x18, &root) || root < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t root_marker = 0;
    if (!TryReadPointer(root, &root_marker) || root_marker != marker) {
        return false;
    }

    uintptr_t health_entry = 0;
    if (TryReadPointer(root + 0x58, &health_entry) && !IsValidStatEntry(health_entry, kHealthId)) {
        health_entry = 0;
    }

    uintptr_t stamina_entry = 0;
    if (health_entry >= kMinimumPointerAddress) {
        const uintptr_t candidate_stamina_entry = health_entry + kStaminaEntryOffsetFromHealth;
        if (IsValidStatEntry(candidate_stamina_entry, kStaminaId)) {
            stamina_entry = candidate_stamina_entry;
        }
    }

    if (health_entry < kMinimumPointerAddress || stamina_entry < kMinimumPointerAddress) {
        TryResolveLargeMountStatEntries(root, &health_entry, &stamina_entry);
    }

    if (health_entry < kMinimumPointerAddress && stamina_entry >= kMinimumPointerAddress) {
        const uintptr_t candidate_health_entry = stamina_entry - kStaminaEntryOffsetFromHealth;
        if (IsValidStatEntry(candidate_health_entry, kHealthId)) {
            health_entry = candidate_health_entry;
        }
    }

    if (stamina_entry < kMinimumPointerAddress && health_entry >= kMinimumPointerAddress) {
        const uintptr_t candidate_stamina_entry = health_entry + kStaminaEntryOffsetFromHealth;
        if (IsValidStatEntry(candidate_stamina_entry, kStaminaId)) {
            stamina_entry = candidate_stamina_entry;
        }
    }

    if (!IsValidStatEntry(health_entry, kHealthId) || !IsValidStatEntry(stamina_entry, kStaminaId)) {
        return false;
    }

    uintptr_t spirit_entry = 0;
    const uintptr_t candidate_spirit_entry = health_entry + kSpiritEntryOffsetFromHealth;
    if (IsValidStatEntry(candidate_spirit_entry, kSpiritId)) {
        spirit_entry = candidate_spirit_entry;
    }

    uintptr_t resolved_actor = 0;
    if (actor_hint >= kMinimumPointerAddress) {
        uintptr_t hint_marker = 0;
        if (TryReadPointer(actor_hint + 0x20, &hint_marker) && hint_marker == marker) {
            resolved_actor = actor_hint;
        }
    }

    if (resolved_actor < kMinimumPointerAddress && !TryResolveActorFromMarker(marker, &resolved_actor)) {
        return false;
    }

    resolved->actor = resolved_actor;
    resolved->marker = marker;
    resolved->root = root;
    resolved->health_entry = health_entry;
    resolved->stamina_entry = stamina_entry;
    resolved->spirit_entry = spirit_entry;
    resolved->damage_source = resolved_actor;
    resolved->damage_target = root;
    return true;
}

bool TryResolveActorResolveFromActor(const uintptr_t actor, ActorResolveSnapshot* const resolved) {
    if (resolved == nullptr || actor < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t marker = 0;
    if (!TryReadPointer(actor + 0x20, &marker) || marker < kMinimumPointerAddress) {
        return false;
    }

    return TryResolveActorResolveFromMarker(marker, resolved, actor);
}

bool TryResolveActorResolveFromRoot(const uintptr_t root, ActorResolveSnapshot* const resolved) {
    if (resolved == nullptr || root < kMinimumPointerAddress) {
        return false;
    }

    uintptr_t marker = 0;
    if (!TryReadPointer(root, &marker) || marker < kMinimumPointerAddress) {
        return false;
    }

    return TryResolveActorResolveFromMarker(marker, resolved);
}

bool TryResolveActorResolveFromContextRoot(const uintptr_t context_root,
                                          ActorResolveSnapshot* const resolved,
                                          const ActorResolveSnapshot& player_snapshot) {
    if (!TryResolveActorResolveFromRoot(context_root, resolved)) {
        return false;
    }

    if (!resolved->valid()) {
        return false;
    }

    if (player_snapshot.valid() &&
        (resolved->marker == player_snapshot.marker || resolved->root == player_snapshot.root)) {
        return false;
    }

    return true;
}
