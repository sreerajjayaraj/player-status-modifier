#include "mod_logic.h"

#include "config.h"
#include "logger.h"
#include "runtime/actor_resolve.h"
#include "runtime/mount_resolver.h"
#include "runtime/runtime_state.h"

#include <cmath>
#include <cstdint>
#include <limits>

namespace {

constexpr int64_t kDragonHealthMaxThreshold = 2500000;
constexpr int64_t kDragonStaminaMaxThreshold = 300000;
constexpr int64_t kHorseHealthMaxThreshold = 40000;
constexpr int64_t kHorseStaminaMaxThreshold = 1000;

bool TryReadStatMaxValue(const uintptr_t entry, int64_t* const max_value) {
    if (max_value == nullptr || entry < kMinimumPointerAddress) {
        return false;
    }

    __try {
        *max_value = *reinterpret_cast<const int64_t*>(entry + 0x18);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool TryReadMountProfileMaxima(const ActorResolveSnapshot& snapshot,
                               int64_t* const health_max,
                               int64_t* const stamina_max) {
    if (!snapshot.valid() || health_max == nullptr || stamina_max == nullptr) {
        return false;
    }

    return TryReadStatMaxValue(snapshot.health_entry, health_max) &&
           TryReadStatMaxValue(snapshot.stamina_entry, stamina_max);
}

bool IsDragonMountProfile(const ActorResolveSnapshot& snapshot) {
    int64_t health_max = 0;
    int64_t stamina_max = 0;
    if (!TryReadMountProfileMaxima(snapshot, &health_max, &stamina_max)) {
        return false;
    }

    return health_max >= kDragonHealthMaxThreshold &&
           stamina_max >= kDragonStaminaMaxThreshold;
}

bool IsSupportedMountProfile(const ActorResolveSnapshot& snapshot) {
    int64_t health_max = 0;
    int64_t stamina_max = 0;
    if (!TryReadMountProfileMaxima(snapshot, &health_max, &stamina_max)) {
        return false;
    }

    const bool dragon_profile =
        health_max >= kDragonHealthMaxThreshold &&
        stamina_max >= kDragonStaminaMaxThreshold;
    const bool horse_profile =
        health_max >= kHorseHealthMaxThreshold &&
        stamina_max >= kHorseStaminaMaxThreshold;
    return dragon_profile || horse_profile;
}

const char* MountProfileName(const ActorResolveSnapshot& snapshot) {
    int64_t health_max = 0;
    int64_t stamina_max = 0;
    if (!TryReadStatMaxValue(snapshot.health_entry, &health_max) ||
        !TryReadStatMaxValue(snapshot.stamina_entry, &stamina_max)) {
        return "unknown";
    }

    if (health_max >= kDragonHealthMaxThreshold &&
        stamina_max >= kDragonStaminaMaxThreshold) {
        return "dragon";
    }

    if (health_max >= kHorseHealthMaxThreshold &&
        stamina_max >= kHorseStaminaMaxThreshold) {
        return "horse";
    }

    return "rejected";
}

bool TryResolveMountSnapshotFromContextRoot(const uintptr_t context_root,
                                           ActorResolveSnapshot* const resolved,
                                           const bool allow_horse_profile) {
    if (resolved == nullptr || context_root < kMinimumPointerAddress) {
        return false;
    }

    const ActorResolveSnapshot player_snapshot = g_player_resolve;
    if (!player_snapshot.valid()) {
        return false;
    }

    if (!TryResolveActorResolveFromContextRoot(context_root, resolved, player_snapshot)) {
        return false;
    }

    // Health-root damage callbacks can point at enemies/destructibles.  Keep
    // those broad callbacks dragon-only to avoid making ordinary enemies
    // invulnerable.  The horse-sized profile is accepted only from the stamina
    // owner context or from the explicit mount marker chain.
    return allow_horse_profile ? IsSupportedMountProfile(*resolved) : IsDragonMountProfile(*resolved);
}

}  // namespace

void ResetRuntimeState() {
    std::lock_guard lock(g_state_mutex);
    g_player_resolve = {};
    g_mount_resolve = {};
    ResetTrackedEntriesLocked();
    ResetTrackedDamageParticipantsLocked();
    g_runtime_enabled.store(true, std::memory_order_release);
}

void DisableRuntimeProcessing() {
    g_runtime_enabled.store(false, std::memory_order_release);
}

bool StartMountResolver() {
    return StartMountResolverLoop();
}

void StopMountResolver() {
    StopMountResolverLoop();
}

bool TryScaleItemGain(const int64_t amount, int64_t* const value) {
    if (!g_runtime_enabled.load(std::memory_order_acquire) || value == nullptr) {
        return false;
    }

    const auto& config = GetConfig();
    if (!config.general.enabled || config.items.gain_multiplier == 1.0 || amount <= 0) {
        return false;
    }

    const double scaled = std::floor(static_cast<double>(amount) * config.items.gain_multiplier);
    if (scaled <= 0.0) {
        *value = 0;
        return true;
    }

    if (scaled >= static_cast<double>(std::numeric_limits<int64_t>::max())) {
        *value = std::numeric_limits<int64_t>::max();
        return true;
    }

    *value = static_cast<int64_t>(scaled);
    return *value != amount;
}

void UpdateTrackedMountFromHealthRoot(const uintptr_t root) {
    ActorResolveSnapshot resolved{};
    if (!TryResolveMountSnapshotFromContextRoot(root, &resolved, false)) {
        return;
    }

    UpdateTrackedMountStatusComponent(resolved.actor, resolved.marker);
}

void UpdateTrackedMountFromStaminaContext(const uintptr_t stamina_entry, const uintptr_t context_root) {
    if (stamina_entry < kMinimumPointerAddress) {
        return;
    }

    ActorResolveSnapshot resolved{};
    if (!TryResolveMountSnapshotFromContextRoot(context_root, &resolved, true)) {
        return;
    }

    if (resolved.stamina_entry != stamina_entry) {
        return;
    }

    UpdateTrackedMountStatusComponent(resolved.actor, resolved.marker);
}

void UpdateTrackedMountStatusComponent(const uintptr_t actor, const uintptr_t marker) {
    if (marker < kMinimumPointerAddress) {
        return;
    }

    const uintptr_t player_marker = g_player_resolve.marker;
    if (marker == player_marker) {
        return;
    }

    ActorResolveSnapshot resolved{};
    if (!TryResolveActorResolveFromMarker(marker, &resolved, actor)) {
        return;
    }

    if (resolved.marker == g_player_resolve.marker || resolved.root == g_player_resolve.root) {
        return;
    }

    const ActorResolveSnapshot current_mount = g_mount_resolve;
    if (current_mount.actor == resolved.actor && current_mount.marker == resolved.marker) {
        return;
    }

    std::lock_guard lock(g_state_mutex);
    if (g_mount_resolve.actor == resolved.actor && g_mount_resolve.marker == resolved.marker) {
        return;
    }

    g_mount_resolve = resolved;

    const auto current = g_actor_resolve_logs.fetch_add(1, std::memory_order_acq_rel);
    if (current < 24) {
        Log("runtime: tracked mount profile=%s actor=0x%p root=0x%p status_marker=0x%p health=0x%p stamina=0x%p spirit=0x%p",
            MountProfileName(resolved),
            reinterpret_cast<void*>(resolved.actor),
            reinterpret_cast<void*>(resolved.root),
            reinterpret_cast<void*>(resolved.marker),
            reinterpret_cast<void*>(resolved.health_entry),
            reinterpret_cast<void*>(resolved.stamina_entry),
            reinterpret_cast<void*>(resolved.spirit_entry));
    }
}

void UpdateTrackedPlayerStatusComponent(const uintptr_t actor, const uintptr_t component) {
    if (component < kMinimumPointerAddress) {
        return;
    }

    ActorResolveSnapshot resolved{};
    if (!TryResolveActorResolveFromMarker(component, &resolved, actor)) {
        return;
    }

    std::lock_guard lock(g_state_mutex);

    const ActorResolveSnapshot existing = g_player_resolve;
    if (existing.marker == component && existing.health_entry == resolved.health_entry) {
        return;
    }

    if (existing.health_entry >= kMinimumPointerAddress &&
        resolved.health_entry >= kMinimumPointerAddress &&
        existing.health_entry != resolved.health_entry) {
        const auto current = g_actor_resolve_logs.fetch_add(1, std::memory_order_acq_rel);
        if (current < 24) {
            Log("runtime: ignored player status update with different health current_health=0x%p resolved_health=0x%p status_marker=0x%p",
                reinterpret_cast<void*>(existing.health_entry),
                reinterpret_cast<void*>(resolved.health_entry),
                reinterpret_cast<void*>(resolved.marker));
        }
        return;
    }

    ActorResolveSnapshot merged = resolved;
    if (existing.health_entry >= kMinimumPointerAddress &&
        resolved.health_entry == existing.health_entry) {
        merged = existing;
        if (merged.actor < kMinimumPointerAddress) {
            merged.actor = resolved.actor;
        }
        if (merged.marker < kMinimumPointerAddress) {
            merged.marker = resolved.marker;
        }
        if (merged.root < kMinimumPointerAddress) {
            merged.root = resolved.root;
        }
        if (merged.stamina_entry < kMinimumPointerAddress) {
            merged.stamina_entry = resolved.stamina_entry;
        }
        if (merged.spirit_entry < kMinimumPointerAddress) {
            merged.spirit_entry = resolved.spirit_entry;
        }
    } else {
        ResetTrackedEntriesLocked();
        ResetTrackedMountLocked();
        ResetTrackedDamageParticipantsLocked();
    }

    g_player_resolve = merged;

    Log("runtime: tracked player actor=0x%p status_marker=0x%p stat_root=0x%p",
        reinterpret_cast<void*>(merged.actor),
        reinterpret_cast<void*>(merged.marker),
        reinterpret_cast<void*>(merged.root));

    RefreshTrackedMountFromPlayerActor();
}

uintptr_t GetTrackedPlayerStatRoot() {
    return g_player_resolve.root;
}

uintptr_t GetTrackedMountActor() {
    return g_mount_resolve.actor;
}

uintptr_t GetTrackedMountStatRoot() {
    return g_mount_resolve.root;
}

uintptr_t GetTrackedMountStatusMarker() {
    return g_mount_resolve.marker;
}

uintptr_t GetTrackedPlayerActor() {
    return g_player_resolve.actor;
}

uintptr_t GetTrackedPlayerHealthEntry() {
    return g_player_resolve.health_entry;
}

uintptr_t GetTrackedPlayerSpiritEntry() {
    return g_player_resolve.spirit_entry;
}

uintptr_t GetTrackedPlayerStaminaEntry() {
    return g_player_resolve.stamina_entry;
}

uintptr_t GetTrackedPlayerStatusMarker() {
    return g_player_resolve.marker;
}
